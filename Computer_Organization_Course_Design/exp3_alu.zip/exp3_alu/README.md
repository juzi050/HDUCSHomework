# 实验 3 多功能 ALU Vivado 工程

本工程面向 HCS-A02 教学 FPGA 开发板，实现一个 32 位、8 功能 ALU。板上使用 36 个拨码开关直接输入数据和选择运算，使用按键锁存 A/B，LED 和 8 位数码管显示结果。

## 文件说明

- `src/ALU.v`：顶层模块。
- `src/Third_experiment_second.v`：按键输入控制模块，将 `SW[31:0]` 锁存到 A/B，并控制 LED 显示模式。
- `src/Third_experiment_first.v`：ALU 核心模块，实现 8 种运算和 `ZF/OF` 标志。
- `src/Third_experiment_third.v`：LED 显示模块，选择显示 A、B 或 F，并输出标志位。
- `src/Third_experiment_fourth.v`：8 位数码管动态扫描模块，将 32 位结果 `F` 显示为 8 个十六进制数。
- `sim/tb_ALU.v`：仿真测试文件。
- `constrs/HCS_A02.xdc`：HCS-A02 开关、按键、LED、时钟和数码管管脚约束。
- `scripts/create_project.tcl`：创建 Vivado 工程。
- `scripts/run_all.tcl`：运行仿真、综合、实现并生成 bitstream。

## 板卡输入

- `SW[31:0]`：当前 32 位输入数据。
- `SW[34:32]`：ALU 运算选择 `ALU_OP`。
- `SW[35]`：保留不用。
- `BT0`：把当前 `SW[31:0]` 锁存到 A。
- `BT1`：把当前 `SW[31:0]` 锁存到 B。
- `BT2`：清空 A/B，并将 LED 显示恢复为结果 F。
- `BT3`：切换 LED 显示内容，顺序为 F -> A -> B -> F。

`ALU_OP` 功能：

| `SW[34:32]` | 功能 |
| --- | --- |
| `000` | `A & B` |
| `001` | `A | B` |
| `010` | `A ^ B` |
| `011` | `A ~^ B` |
| `100` | `A + B` |
| `101` | `A - B` |
| `110` | 有符号比较，`A < B` 时输出 1，否则输出 0 |
| `111` | `B << A`，当 `A >= 32` 时输出 0 |

## 板卡显示

- `LD[31:0]`：显示当前选择的 32 位数据。
- `LD[32]`：零标志 `ZF`，结果为 0 时亮。
- `LD[33]`：溢出标志 `OF`，有符号加减溢出时亮。
- `LD[35:34]`：LED 显示模式，`00=A`，`01=B`，`10=F`。
- `AN[7:0]`、`SEG[7:0]`：8 位数码管，持续显示 ALU 结果 `F` 的 8 位十六进制值。

`SEG[0]~SEG[6]` 对应 `CA~CG`，`SEG[7]` 对应 `DP`。HCS-A02 的数码管为共阳极，位选和段选均为低电平有效。

## 板上测试步骤

1. 拨 `SW[31:0]` 为 A 的 32 位值，按 `BT0`。
2. 拨 `SW[31:0]` 为 B 的 32 位值，按 `BT1`。
3. 拨 `SW[34:32]` 选择 ALU 运算。
4. 查看数码管是否显示结果 F 的 8 位十六进制值。
5. 查看 `LD[32]` 是否为 `ZF`，`LD[33]` 是否为 `OF`。
6. 按 `BT3` 切换 `LD[31:0]`，确认能查看 F、A、B。
7. 按 `BT2` 清空，进入下一组测试。

## 运行命令

在 PowerShell 中进入本目录后执行：

```powershell
& "E:\Vivado\2025.1\Vivado\bin\vivado.bat" -mode batch -source .\scripts\run_all.tcl
```

生成的 Vivado 图形工程默认位于 `vivado_project`。如果该目录被已打开的 Vivado 占用，脚本会自动改用 `vivado_project_batch` 作为临时工程目录。

综合实现后的文件位于 `build`，下载到板子的 bit 文件为：

```text
build\ALU.bit
```
